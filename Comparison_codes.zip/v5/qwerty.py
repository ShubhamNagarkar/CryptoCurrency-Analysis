# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '.\qwerty.ui'
#
# Created by: PyQt5 UI code generator 5.9
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import qwerty2
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtWidgets.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtWidgets.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtWidgets.QApplication.translate(context, text, disambig)


class Ui_Front(object):
    def scndwin(self):
        self.window=QtWidgets.QMainWindow()
        self.ui=qwerty2.Ui_mid()
        self.ui.setupUi(self.window)
        self.window.show()

    
    def cryp(self):
        self.textBrowser_2 = QtWidgets.QTextBrowser(self.centralwidget)
        self.textBrowser_2.setObjectName(_fromUtf8("textBrowser_2"))
        self.formLayout.setWidget(5, QtWidgets.QFormLayout.FieldRole, self.textBrowser_2)
        _translate = QtCore.QCoreApplication.translate
        self.textBrowser_2.setHtml(_translate("Front", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:11pt; color:#ee1501;\">A  </span><span style=\" font-size:11pt; font-weight:600; color:#b54022;\">cryptocurrency</span><span style=\" font-size:11pt;\"> </span><span style=\" font-size:11pt; color:#b54022;\">(</span><span style=\" font-size:11pt; color:#ee1501;\">or</span><span style=\" font-size:11pt;\"> </span><span style=\" font-size:11pt; font-weight:600; color:#b54022;\">crypto</span><span style=\" font-size:11pt; color:#b54022;\"> </span><span style=\" font-size:11pt; font-weight:600; color:#b54022;\">currency</span><span style=\" font-size:11pt; color:#b54022;\">) </span><span style=\" font-size:11pt; color:#ee1501;\">is a </span><a href=\"https://en.wikipedia.org/wiki/Digital_asset\"><span style=\" font-size:11pt; text-decoration: underline; color:#ee1501;\">digital asset</span></a><span style=\" font-size:11pt; color:#ee1501;\"> designed to work as a </span><a href=\"https://en.wikipedia.org/wiki/Medium_of_exchange\"><span style=\" font-size:11pt; text-decoration: underline; color:#ee1501;\">medium of exchange</span></a><span style=\" font-size:11pt; color:#ee1501;\"> using </span><a href=\"https://en.wikipedia.org/wiki/Cryptography\"><span style=\" font-size:11pt; text-decoration: underline; color:#ee1501;\">cryptography</span></a><span style=\" font-size:11pt; color:#ee1501;\"> to secure the transactions and to control the creation of additional units of the currency.</span><span style=\" font-size:11pt; text-decoration: underline; color:#ee1501; vertical-align:super;\">]</span><span style=\" font-size:11pt; color:#ee1501;\"> Cryptocurrencies are classified as a subset of </span><a href=\"https://en.wikipedia.org/wiki/Digital_currency\"><span style=\" font-size:11pt; text-decoration: underline; color:#ee1501;\">digital currencies</span></a><span style=\" font-size:11pt; color:#ee1501;\"> and are also classified as a subset of </span><a href=\"https://en.wikipedia.org/wiki/Alternative_currency\"><span style=\" font-size:11pt; text-decoration: underline; color:#ee1501;\">alternative currencies</span></a><span style=\" font-size:11pt; color:#ee1501;\"> and </span><a href=\"https://en.wikipedia.org/wiki/Virtual_currency\"><span style=\" font-size:11pt; text-decoration: underline; color:#ee1501;\">virtual currencies</span></a><span style=\" font-size:11pt; color:#ee1501;\">.</span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><a href=\"https://en.wikipedia.org/wiki/Bitcoin\"><span style=\" font-size:11pt; text-decoration: underline; color:#ee1501;\">Bitcoin</span></a><span style=\" font-size:11pt; color:#ee1501;\"> became the first decentralized cryptocurrency in 2009. Since then, numerous cryptocurrencies have been created. These are frequently called </span><span style=\" font-size:11pt; font-style:italic; color:#ee1501;\">altcoins</span><span style=\" font-size:11pt; color:#ee1501;\">, as a </span><a href=\"https://en.wikipedia.org/wiki/Blend_word\"><span style=\" font-size:11pt; text-decoration: underline; color:#ee1501;\">blend</span></a><span style=\" font-size:11pt; color:#ee1501;\"> of </span><span style=\" font-size:11pt; font-style:italic; color:#ee1501;\">bitcoin alternative</span><span style=\" font-size:11pt; color:#ee1501;\">. Bitcoin and its derivatives use decentralized control as opposed to centralized </span><a href=\"https://en.wikipedia.org/wiki/Electronic_money\"><span style=\" font-size:11pt; text-decoration: underline; color:#ee1501;\">electronic money</span></a><span style=\" font-size:11pt; color:#ee1501;\">/centralized </span><a href=\"https://en.wikipedia.org/wiki/Bank\"><span style=\" font-size:11pt; text-decoration: underline; color:#ee1501;\">banking</span></a><span style=\" font-size:11pt; color:#ee1501;\"> systems. The decentralized control is related to the use of </span><a href=\"https://en.wikipedia.org/wiki/Bitcoin#Blockchain\"><span style=\" font-size:11pt; text-decoration: underline; color:#ee1501;\">bitcoin\'s blockchain</span></a><span style=\" font-size:11pt; color:#ee1501;\"> transaction database in the role of a distributed </span><a href=\"https://en.wikipedia.org/wiki/Ledger\"><span style=\" font-size:11pt; text-decoration: underline; color:#ee1501;\">ledger</span></a></p></body></html>In this project we compare stock prices of various currencies to provide a general analysis of trends and have made a attempt to suggest user to whether buy a certain currency or not"))
        self.textBrowser_2.show()
        
    def setupUi(self, Front):
        Front.setObjectName("Front")
        Front.resize(1148, 820)
        Front.setStyleSheet("")
        self.centralwidget = QtWidgets.QWidget(Front)
        self.centralwidget.setObjectName("centralwidget")
        self.formLayout = QtWidgets.QFormLayout(self.centralwidget)
        self.formLayout.setFieldGrowthPolicy(QtWidgets.QFormLayout.AllNonFixedFieldsGrow)
        self.formLayout.setObjectName("formLayout")
        self.textBrowser = QtWidgets.QTextBrowser(self.centralwidget)
        self.textBrowser.setStyleSheet("border-color: rgb(14, 81, 188);")
        self.textBrowser.setObjectName("textBrowser")
        self.formLayout.setWidget(0, QtWidgets.QFormLayout.FieldRole, self.textBrowser)
        spacerItem = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.formLayout.setItem(1, QtWidgets.QFormLayout.FieldRole, spacerItem)
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Franklin Gothic Demi")
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setObjectName("pushButton_2")
        self.formLayout.setWidget(2, QtWidgets.QFormLayout.FieldRole, self.pushButton_2)
        
        self.pushButton_2.clicked.connect(self.scndwin)
        
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Franklin Gothic Demi")
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton.setFont(font)
        self.pushButton.setAutoFillBackground(True)
        self.pushButton.setStyleSheet("color: rgb(0, 0, 0);")
        self.pushButton.setObjectName("pushButton")
        self.formLayout.setWidget(3, QtWidgets.QFormLayout.FieldRole, self.pushButton)
        
        self.pushButton.clicked.connect(self.cryp)
        
       # self.textBrowser_2 = QtWidgets.QTextBrowser(self.centralwidget)
        #self.textBrowser_2.setObjectName("textBrowser_2")
        # self.formLayout.setWidget(7, QtWidgets.QFormLayout.FieldRole, self.textBrowser_2)
        """self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        font = QtGui.QFont()
        font.setFamily("Franklin Gothic Demi")
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_3.clicked.connect(c.predui)
        self.formLayout.setWidget(4, QtWidgets.QFormLayout.FieldRole, self.pushButton_3)"""
        spacerItem1 = QtWidgets.QSpacerItem(20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Preferred)
        self.formLayout.setItem(6, QtWidgets.QFormLayout.FieldRole, spacerItem1)
        Front.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(Front)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1148, 31))
        self.menubar.setObjectName("menubar")
        Front.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(Front)
        self.statusbar.setObjectName("statusbar")
        Front.setStatusBar(self.statusbar)

        self.retranslateUi(Front)
        QtCore.QMetaObject.connectSlotsByName(Front)

    def retranslateUi(self, Front):
        _translate = QtCore.QCoreApplication.translate
        Front.setWindowTitle(_translate("Front", "MainWindow"))
        self.textBrowser.setHtml(_translate("Front", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;\"><br /></p>\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;\"><br /></p>\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;\"><br /></p>\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:48pt; font-weight:600; color:#dad424;\">CRYPTO-CURRENCY</span></p></body></html>"))
        self.pushButton_2.setText(_translate("Front", "Start"))
        self.pushButton.setText(_translate("Front", "About"))
        #self.pushButton_3.setText(_translate("Front", "Predict"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Front = QtWidgets.QMainWindow()
    ui = Ui_Front()
    ui.setupUi(Front)
    Front.show()
    sys.exit(app.exec_())

