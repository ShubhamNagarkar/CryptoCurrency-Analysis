'''
Created on 20-Sep-2017

@author: Shubham L Nagarkar
'''
import pandas as pd
import numpy as np
import matplotlib.pylab as plt

df=pd.read_csv('resources/ripple_price.csv')
cnt0=cnt1=cnt2=cnt3=cnt4=cnt5=0
max_fall_2017=max_rise_2017=0.0
max_fall_2016=max_rise_2016=0.0
max_fall_2015=max_rise_2015=0.0
max_fall_2014=max_rise_2014=0.0


for item1 in df["Date"]:
    item1=str(item1)
    if item1[8:]=="2017":
        cnt0+=1
        
    elif item1[8:]=="2016":
        cnt1+=1
        
    elif item1[8:]=="2015":
        cnt2+=1
        
    elif item1[8:]=="2014":
        cnt3+=1
    

df2017=df.iloc[0:cnt0,0:7]
df2016=df.iloc[(cnt0):cnt0+cnt1,0:7]
df2015=df.iloc[cnt0+cnt1:cnt0+cnt1+cnt2,0:7]
df2014=df.iloc[cnt0+cnt1+cnt2:cnt0+cnt1+cnt2+cnt3,0:7]

max_rise_2017=max(df2017["High"])
max_rise_2016=max(df2016["High"])
max_rise_2015=max(df2015["High"])
max_rise_2014=max(df2014["High"])

max_fall_2017=min(df2017["Low"])
max_fall_2016=min(df2016["Low"])
max_fall_2015=min(df2015["Low"])
max_fall_2014=min(df2014["Low"])


item1=df2017["Market Cap"].tolist()
item2=df2016["Market Cap"].tolist()
item3=df2015["Market Cap"].tolist()
item4=df2014["Market Cap"].tolist()

def average_cap(item):
    llist=[]
    for i in item:
        j=i.replace(",", "")   #remove commas
        llist.append(int(j))
        
    avg1=sum(llist)/len(llist)
    return(avg1)

marketcap_2017=average_cap(item1)
marketcap_2016=average_cap(item2)
marketcap_2015=average_cap(item3)
marketcap_2014=average_cap(item4)


def display_graph(list_grph,s):
    
    llist=list_grph
    llist.reverse()
    N = len(llist)
    x = range(N)
    plt.plot(x, llist)
    plt.xticks(np.arange(min(x), max(x)+1, 30))
    plt.xlabel("No. of Days ")
    plt.ylabel("Value of currency")
    plt.title(s)
    #plt.xticks(x, l1, color='black',)  to give labels on x axis bars
    plt.show()
    llist.reverse()
    
l1=df2017["High"].tolist()
l2=df2016["High"].tolist()
l3=df2015["High"].tolist()
l4=df2014["High"].tolist()
l5=df2017["Low"].tolist()
l6=df2016["Low"].tolist()
l7=df2015["Low"].tolist()
l8=df2014["Low"].tolist()

"""
print("\n Stats for the year : 2017 ")
print("Rise : ",max_rise_2017," Fall : ",max_fall_2017," Avg Market Cap : ",marketcap_2017)
display_graph(l1,"2017 High values for Ripple")
display_graph(l5,"2017 Low values for Ripple")
print("\n Stats for the year : 2016 ")
print("Rise : ",max_rise_2016," Fall : ",max_fall_2016," Avg Market Cap : ",marketcap_2016)

display_graph(l2,"2016 High values for Ripple")
display_graph(l6,"2016 Low values for Ripple")
print("\n Stats for the year : 2015 ")
print("Rise : ",max_rise_2015," Fall : ",max_fall_2015," Avg Market Cap : ",marketcap_2015)

display_graph(l3,"2015 High values for Ripple")
display_graph(l7,"2015 Low values for Ripple")

print("\n Stats for the year : 2014 ")
print("Rise : ",max_rise_2014," Fall : ",max_fall_2014," Avg Market Cap : ",marketcap_2014)
display_graph(l4,"2014 High values for Ripple")
display_graph(l8,"2014 Low values for Ripple")"""


ll1=[df2017["High"].mean(),df2016["High"].mean(),df2015["High"].mean(),df2014["High"].mean()]
ll2=[df2017["Low"].mean(),df2016["Low"].mean(),df2015["Low"].mean(),df2014["Low"].mean()]


def comparison(l1,s1):
    llist1=l1
    colours=['r','m','b','y']
    width = 1
    l1=['2017','2016','2015','2014']
    N = len(llist1)
    x = range(N)
    plt.bar(x,llist1,color=colours)
    plt.xticks(x, l1, color='black',)
    plt.xlabel("Year")
    plt.ylabel("Mean value")
    plt.title(s1)
    plt.show()
	
def compui1():   
	comparison(ll1,"Year wise comparison of Mean High values")
def compui2():
	comparison(ll2,"Year wise comparison of Mean Low values")


def stacked_bargrph():
    mpl_fig = plt.figure()
    ax = mpl_fig.add_subplot(111)
    l1=['2017','2016','2015','2014']
    N = len(ll1)
    x = range(N)
    p1=ax.bar(x,ll1,color='black')
    p2=ax.bar(x,ll2,color='blue',bottom=ll1)
    ax.set_ylabel('Mean high and low Values')
    ax.set_xlabel('Year')
    ax.set_title('Year wise comparison of Mean High and Low values')
    #ax.set_xticklabels(["X","2017","2016","2015","2014"])
    plt.xticks(x, l1, color='black',)
    plt.legend((p1[0], p2[0]), ('High', 'Low'))
    plt.show()

def stacked_ui():   
	stacked_bargrph()


def indranilhigh():
    plt.figure(1)
    l1.reverse()
    l2.reverse()
    l3.reverse()
    l4.reverse()

    plt.figure(1)
    
    N1 = len(l1)
    x1 = range(N1)
    
    N2 = len(l2)
    x2 = range(N2)
    
    N3 = len(l3)
    x3 = range(N3)
    
    N4 = len(l4)
    x4 = range(N4)

    plt.plot(x1, l1)
    plt.plot(x2, l2)
    plt.plot(x3, l3)
    plt.plot(x4, l4)

    plt.xticks(np.arange(min(x1), max(x1)+1, 30))
    plt.xlabel("No. of Days ")
    plt.ylabel("High-value of currency")
    plt.title("Year-wise Comparison")
    plt.legend(['2017', '2016', '2015', '2014'], loc='upper left')
    plt.show()
    l1.reverse()
    l2.reverse()
    l3.reverse()
    l4.reverse()


def indranillow():
    plt.figure(1)
    l5.reverse()
    l6.reverse()
    l7.reverse()
    l8.reverse()

    plt.figure(1)
    
    N1 = len(l5)
    x1 = range(N1)
    
    N2 = len(l6)
    x2 = range(N2)
    
    N3 = len(l7)
    x3 = range(N3)
    
    N4 = len(l8)
    x4 = range(N4)

    plt.plot(x1, l5)
    plt.plot(x2, l6)
    plt.plot(x3, l7)
    plt.plot(x4, l8)

    plt.xticks(np.arange(min(x1), max(x1)+1, 30))
    plt.xlabel("No. of Days ")
    plt.ylabel("Loq-value of currency")
    plt.title("Year-wise Comparison")
    plt.legend(['2017', '2016', '2015', '2014'], loc='upper left')
    plt.show()
    l5.reverse()
    l6.reverse()
    l7.reverse()
    l8.reverse()

def subplot_graph_highval():
    plt.figure(1)
    l1.reverse()
    l2.reverse()
    l3.reverse()
    l4.reverse()
    N = len(l1)
    x = range(N)
    
    plt.subplot(221)
    plt.plot(x, l1)
    #plt.yscale('linear')
    plt.title('2017 High values')
    plt.ylabel("Value of currency") 
    plt.grid(True)
    
    N1 = len(l2)
    x1 = range(N1)
    plt.subplot(222)
    plt.plot(x1, l2)
    #plt.yscale('linear')
    plt.title('2016 High values')
    plt.ylabel("Value of currency")
    plt.grid(True)
    
    n2 = len(l3)
    x2 = range(n2)
    plt.subplot(223)
    plt.plot(x2, l3)
    #plt.yscale('linear')
    plt.title('2015 High values')
 
    plt.xlabel("No. of Days")
    plt.grid(True)
    
    N3 = len(l4)
    x3 = range(N3)
    plt.subplot(224)
    plt.plot(x3, l4)
    #plt.yscale('linear')
    plt.title('2014 High values')
    plt.xlabel("No. of Days")
    plt.grid(True)
    plt.show()
    l1.reverse()
    l2.reverse()
    l3.reverse()
    l4.reverse()
    
def highvalui():    
	subplot_graph_highval()

def subplot_graph_lowval():
    plt.figure(1)
    l5.reverse()
    l6.reverse()
    l7.reverse()
    l8.reverse()

    
    N = len(l5)
    x = range(N)
    
    plt.subplot(221)
    plt.plot(x, l5)
    #plt.yscale('linear')
    plt.title('2017 Low values')
    plt.ylabel("Value of currency") 
    plt.grid(True)
    
    N1 = len(l6)
    x1 = range(N1)
    plt.subplot(222)
    plt.plot(x1, l6)
    #plt.yscale('linear')
    plt.title('2016 Low values')
    plt.ylabel("Value of currency")
    plt.grid(True)
    
    n2 = len(l7)
    x2 = range(n2)
    plt.subplot(223)
    plt.plot(x2, l7)
    #plt.yscale('linear')
    plt.title('2015 Low values')
 
    plt.xlabel("No. of Days")
    plt.grid(True)
    
    N3 = len(l8)
    x3 = range(N3)
    plt.subplot(224)
    plt.plot(x3, l8)
    #plt.yscale('linear')
    plt.title('2014 Low values')
    plt.xlabel("No. of Days")
    plt.grid(True)
    plt.show()
    l5.reverse()
    l6.reverse()
    l7.reverse()
    l8.reverse()
    
def lowvalui():
	subplot_graph_lowval()

    #print(df2017["Low"].iloc[0])"""

if __name__ == "__main__":
	main()
