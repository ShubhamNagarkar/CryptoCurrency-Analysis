'''
Created on 28-Sep-2017

@author: Shubham L Nagarkar
'''
import pandas as pd
import numpy as np
import matplotlib.pylab as plt
import io

df_ripple=pd.read_csv('resources/ripple_price.csv')
df_dash=pd.read_csv('resources/dash_price.csv')                                 #Reads data from CSV into data frame using pandas.
df_bitcoin=pd.read_csv('resources/bitcoin_price.csv')
df_ethereum=pd.read_csv('resources/ethereum_price.csv')
df_litecoin=pd.read_csv('resources/litecoin_price.csv')
df_monero=pd.read_csv('resources/monero_price.csv')
df_nem=pd.read_csv('resources/nem_price.csv')

max_rise_2017=0.0
max_rise_2016=0.0
max_rise_2015=0.0
max_rise_2014=0.0


def count_func(dfname):
    cnt0=cnt1=cnt2=cnt3=cnt4=0
    for item1 in dfname["Date"]:
        item1=str(item1)
        if item1[8:]=="2017":
            cnt0+=1
            
        elif item1[8:]=="2016":                                             #Counting number of entries per year.
            cnt1+=1
            
        elif item1[8:]=="2015":
            cnt2+=1
            
        elif item1[8:]=="2014":
            cnt3+=1

    df2017=dfname.iloc[0:cnt0,0:7]
    df2016=dfname.iloc[(cnt0):cnt0+cnt1,0:7]                                #creating separate dataframes for Year-wise entry.
    df2015=dfname.iloc[cnt0+cnt1:cnt0+cnt1+cnt2,0:7]
    if cnt3!=0:
        df2014=dfname.iloc[cnt0+cnt1+cnt2:cnt0+cnt1+cnt2+cnt3,0:7]     
        return(df2017,df2016,df2015,df2014)
    else:
        return(df2017,df2016,df2015)


df2017r,df2016r,df2015r,df2014r=count_func(df_ripple)
df2017d,df2016d,df2015d,df2014d=count_func(df_dash)
df2017e,df2016e,df2015e,df2014e=count_func(df_ethereum)
df2017b,df2016b,df2015b,df2014b=count_func(df_bitcoin)
df2017l,df2016l,df2015l,df2014l=count_func(df_litecoin)
df2017m,df2016m,df2015m,df2014m=count_func(df_monero)
df2017n,df2016n,df2015n=count_func(df_nem)

    
def graph_yearwise(df1,df2,df3,df4,df5,df6,df7,s):                          #Function to plot graph that compares all the currency High values against each other.
    plt.figure(1)
    llist1=df1["High"].tolist()
    llist2=df2["High"].tolist()
    llist3=df3["High"].tolist()
    llist4=df4["High"].tolist()
    llist5=df5["High"].tolist()
    llist6=df6["High"].tolist()
    llist7=df7["High"].tolist()
    llist1.reverse()
    llist2.reverse()
    llist3.reverse()
    llist4.reverse()
    llist5.reverse()
    llist6.reverse()
    llist7.reverse()
    
    plt.figure(1)
    
    N1 = len(llist1)
    x1 = range(N1)
    
    N2 = len(llist2)
    x2 = range(N2)
    
    N3 = len(llist3)
    x3 = range(N3)
    
    N4 = len(llist4)
    x4 = range(N4)
    
    N5 = len(llist5)
    x5 = range(N5)
    
    N6 = len(llist6)
    x6 = range(N6)
    
    N7 = len(llist7)
    x7 = range(N7)
     
    plt.plot(x1, llist1)
    plt.plot(x2, llist2)
    plt.plot(x3, llist3)
    plt.plot(x4, llist4)
    plt.plot(x5, llist5)
    plt.plot(x6, llist6)
    plt.plot(x7, llist7)
    plt.xticks(np.arange(min(x1), max(x1)+1, 30))
    plt.xlabel("No. of Days Latest to Old ")
    plt.ylabel("Value of currency")
    plt.title(s)
    plt.legend(['Ripple', 'Dash', 'Ethereum', 'Bitcoin','Litecoin','Monero','Nem'], loc='upper left')  #label for each currency
    #plt.xticks(x, l1, color='black',)  to give labels on x axis bars
    plt.show()

def graphui1():
    graph_yearwise(df2017r, df2017d, df2017e, df2017b, df2017l, df2017m, df2017n,"2017 Values for All currencies")
    #plt.savefig('resources/plots/compareall1.png')
def graphui2():
    graph_yearwise(df2016r, df2016d, df2016e, df2016b, df2016l, df2016m, df2016n,"2016 Values for All currencies")
    #plt.savefig('resources/plots/compareall2.png')
def graphui3():
    graph_yearwise(df2015r, df2015d, df2015e, df2015b, df2015l, df2015m, df2015n,"2015 Values for All currencies")
    #plt.savefig('resources/plots/compareall3.png')



"""print("\nSelect Currency name whose value you want to check : ")
print("\n1.Ripple\n2.Dash\n3.Ethereum\n4.Bitcoin\n5.Litecoin\n6.Monero\n7.Nem")
n=int(input())

print("\nEnter Month : ")
month=input()
print("\nEnter Date : ")
date=(input())
print("\nEnter year : ")
year=(input())
flag=0
list1=[]
if n==1:

    for item in df_ripple["Date"]:
        if item[8:]==year and item[0:3]==month and item[4:6]==date :
            str1=month+" "+date+", "+year
            print(df_ripple.loc[df_ripple['Date'] == str1])
            flag=1
    if flag==0:
        print("\nData not available") 
elif n==2:

    for item in df_dash["Date"]:
        if item[8:]==year and item[0:3]==month and item[4:6]==date :
            str1=month+" "+date+", "+year
            print(df_dash.loc[df_dash['Date'] == str1])
    if flag==0:
        print("\nData not available")   
elif n==3:

    for item in df_ethereum["Date"]:
        if item[8:]==year and item[0:3]==month and item[4:6]==date :
            str1=month+" "+date+", "+year
            print(df_ethereum.loc[df_ethereum['Date'] == str1])
    if flag==0:
        print("\nData not available")    
elif n==4:

    for item in df_bitcoin["Date"]:
        if item[8:]==year and item[0:3]==month and item[4:6]==date :
            str1=month+" "+date+", "+year
            print(df_bitcoin.loc[df_bitcoin['Date'] == str1])
    if flag==0:
        print("\nData not available")  
elif n==5:

    for item in df_litecoin["Date"]:
        if item[8:]==year and item[0:3]==month and item[4:6]==date :
            str1=month+" "+date+", "+year
            print(df_litecoin.loc[df_litecoin['Date'] == str1])
    if flag==0:
        print("\nData not available")    
elif n==6:

    for item in df_monero["Date"]:
        if item[8:]==year and item[0:3]==month and item[4:6]==date :
            str1=month+" "+date+", "+year
            print(df_monero.loc[df_monero['Date'] == str1])
    if flag==0:
        print("\nData not available")    
            
elif n==7:

    for item in df_nem["Date"]:
        if item[8:]==year and item[0:3]==month and item[4:6]==date :
            str1=month+" "+date+", "+year
            print(df_nem.loc[df_nem['Date'] == str1])
    if flag==0:
        print("\nData not available")  
else:
    print("\nWrong input! ")       """

if __name__ == "__main__":
	main()    
