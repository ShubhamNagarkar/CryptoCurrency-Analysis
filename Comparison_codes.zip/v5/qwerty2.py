# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '.\qwerty2.ui'
#
# Created by: PyQt5 UI code generator 5.9
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import project_analysis as pa
import predict.lstmpred as prd

class Ui_mid(object):

    def button4(self):
        self.window=QtWidgets.QMainWindow()
        self.ui=pa.Ui_MainWindow_Analysis()
        self.ui.setupUi(self.window)
        self.window.show()
	
    def setupUi(self, mid):
        mid.setObjectName("mid")
        mid.resize(1129, 805)
        self.centralwidget = QtWidgets.QWidget(mid)
        self.centralwidget.setObjectName("centralwidget")
        self.backbtn = QtWidgets.QPushButton(self.centralwidget)
        self.backbtn.setGeometry(QtCore.QRect(1010, 20, 112, 34))
        self.backbtn.setObjectName("backbtn")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(190, 70, 761, 104))
        font = QtGui.QFont()
        font.setFamily("Arial Rounded MT Bold")
        font.setPointSize(45)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet("background-color: rgb(162, 162, 162);\n"
"color: rgb(15, 235, 255);")
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setWordWrap(True)
        self.label.setObjectName("label")
        self.radioButton = QtWidgets.QRadioButton(self.centralwidget)
        self.radioButton.setGeometry(QtCore.QRect(450, 260, 183, 51))
        font = QtGui.QFont()
        font.setFamily("Franklin Gothic Medium")
        font.setPointSize(20)
        font.setBold(True)
        font.setWeight(75)
        self.radioButton.setFont(font)
        self.radioButton.setObjectName("radioButton")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(30, 350, 1071, 53))
        font = QtGui.QFont()
        font.setFamily("Franklin Gothic Demi")
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_4 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_4.setGeometry(QtCore.QRect(30, 430, 1071, 53))	
        self.pushButton_3.clicked.connect(self.button4)
        self.pushButton_4.clicked.connect(prd.uipred)
        self.backbtn.clicked.connect(exit)
        font = QtGui.QFont()
        font.setFamily("Franklin Gothic Demi")
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.pushButton_4.setFont(font)
        self.pushButton_4.setObjectName("pushButton_4")
        mid.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(mid)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1129, 26))
        self.menubar.setObjectName("menubar")
        mid.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(mid)
        self.statusbar.setObjectName("statusbar")
        mid.setStatusBar(self.statusbar)

        self.retranslateUi(mid)
        QtCore.QMetaObject.connectSlotsByName(mid)

    def retranslateUi(self, mid):
        _translate = QtCore.QCoreApplication.translate
        mid.setWindowTitle(_translate("mid", "Menu"))
        self.backbtn.setText(_translate("mid", "ExitAll"))
        self.label.setText(_translate("mid", "!!!WELCOME !!!"))
        self.radioButton.setText(_translate("mid", "Select One"))
        self.pushButton_3.setText(_translate("mid", "Analysis"))
        self.pushButton_4.setText(_translate("mid", "Prediction"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    mid = QtWidgets.QMainWindow()
    ui = Ui_mid()
    ui.setupUi(mid)
    mid.show()
    sys.exit(app.exec_())

